import streamlit as st
import requests

BASE_URL = "https://ai-gym-bncrh9hubtgagkdm.centralindia-01.azurewebsites.net"

st.set_page_config(page_title="AI Gym Assistant", layout="wide")
st.title("🏋️ AI Gym & Fitness Assistant")

menu = ["Diet & BMI", "Gym Recommender", "Workout Sim", "AI Chat Buddy"]
choice = st.sidebar.selectbox("Choose Module", menu)

# ── Diet & BMI ──────────────────────────────────────────────────────────────
if choice == "Diet & BMI":
    st.subheader("Personalized Diet Plan")
    name     = st.text_input("Name")
    weight   = st.number_input("Weight (kg)", 50, 150, 70)
    height   = st.number_input("Height (cm)", 100, 250, 170)
    age      = st.number_input("Age", 10, 100, 25)
    gender   = st.selectbox("Gender", ["male", "female"])
    activity = st.selectbox("Activity Level", ["sedentary", "light", "moderate", "active", "very_active"])
    goal     = st.selectbox("Goal", ["Weight Loss", "Muscle Gain", "Maintenance"])

    if st.button("Calculate & Get Plan"):
        payload = {
            "name": name, "weight_kg": weight, "height_cm": height,
            "age": age, "gender": gender, "activity_level": activity, "goal": goal
        }
        try:
            r = requests.post(f"{BASE_URL}/api/diet/meal-plan", json=payload, timeout=15)
            r.raise_for_status()
            data = r.json()
            st.success(f"Hello {data.get('user', name)}! BMI: **{data.get('bmi')}** ({data.get('bmi_category')}) | Target: **{data.get('target_calories')} kcal/day**")
            meal_plan = data.get('meal_plan', {})
            for meal, items in meal_plan.items():
                st.markdown(f"### {meal.title()}")
                for item in items:
                    st.markdown(f"- **{item['food']}** — {item['grams']}g | {item['calories']} kcal | {item['protein_g']}g protein")
        except requests.exceptions.HTTPError as e:
            st.error(f"Server error {r.status_code}: {r.text}")
        except Exception as e:
            st.error(f"Error connecting to backend: {e}")

# ── Gym Recommender ──────────────────────────────────────────────────────────
elif choice == "Gym Recommender":
    st.subheader("🏋️ Find the Best Gym Near You")
    goal     = st.selectbox("Fitness Goal", ["weight_loss", "muscle_gain", "endurance"])
    budget   = st.slider("Monthly Budget (₹)", 500, 6000, 3000, step=500)
    features = st.multiselect(
        "Preferred Facilities",
        options=["weights", "pool", "classes", "24hr", "pt"],
        default=["weights"]
    )

    if st.button("Find Gyms"):
        payload = {"goal": goal, "budget": budget, "features": features}
        try:
            r = requests.post(f"{BASE_URL}/api/gyms/recommend", json=payload, timeout=15)
            r.raise_for_status()
            data = r.json()
            gyms = data.get("top_gyms", [])

            if gyms:
                st.success(f"Top {len(gyms)} gyms for your goal!")
                for gym in gyms:
                    feats = [k for k in ['weights','pool','classes','24hr','pt'] if gym.get(k)]
                    with st.container():
                        col1, col2, col3, col4 = st.columns(4)
                        col1.metric("Gym",         gym.get("name", "N/A"))
                        col2.metric("Match Score", f"{gym.get('match', 0)}")
                        col3.metric("Monthly Fee", f"₹{gym.get('fee', 0)}")
                        col4.metric("Rating",      f"⭐ {gym.get('rating', 0)}")
                        st.caption(f"📍 {gym.get('dist', 0)} km away | Facilities: {', '.join(feats) if feats else 'Basic'}")
                        st.divider()
            else:
                st.warning("No gyms found for your criteria.")

            if data.get("program"):
                st.markdown(f"### 📅 Recommended Program: {data['program']}")
                st.markdown(f"**Duration:** {data.get('weeks', 0)} weeks | **{data.get('days', 0)} days/week**")
                weekly = data.get("weekly_plan", {})
                if weekly:
                    for day, activity in weekly.items():
                        st.markdown(f"- **{day}:** {activity}")

        except requests.exceptions.HTTPError as e:
            st.error(f"Server error {r.status_code}: {r.text}")
        except Exception as e:
            st.error(f"Error connecting to backend: {e}")

# ── Workout Simulator ─────────────────────────────────────────────────────────
elif choice == "Workout Sim":
    st.subheader("🤸 AI Workout Analyzer (YOLOv8 Pose)")
    exercise = st.selectbox(
        "Select Exercise",
        ["bicep_curl", "squat", "pushup", "shoulder_press", "deadlift", "lunge"]
    )
    video_file = st.file_uploader(
        "Upload a workout video (MP4, MOV, AVI)",
        type=["mp4", "mov", "avi"]
    )
    st.info("Upload a video of yourself performing the exercise. YOLO will detect your pose frame-by-frame, count reps, and score your form.")

    if st.button("Analyze Video"):
        if video_file is None:
            st.warning("Please upload a video file first.")
        else:
            with st.spinner("Analyzing video with YOLOv8 pose detection... this may take 30-60 seconds."):
                try:
                    r = requests.post(
                        f"{BASE_URL}/api/workout/analyze",
                        params={"exercise": exercise},
                        files={"video": (video_file.name, video_file, video_file.type)},
                        timeout=120
                    )
                    r.raise_for_status()
                    data = r.json()

                    st.success(f"✅ Analysis complete for: **{data.get('exercise', exercise).replace('_', ' ').title()}**")

                    col1, col2, col3 = st.columns(3)
                    col1.metric("Reps Detected",   data.get('reps_detected', 0))
                    col2.metric("Form Score",       f"{data.get('form_score', 0)}%")
                    col3.metric("Frames Analyzed",  data.get('frames_analyzed', 0))

                    col4, col5, col6 = st.columns(3)
                    col4.metric("Avg Joint Angle",  f"{data.get('avg_angle', 0)}°")
                    col5.metric("Min Angle",        f"{data.get('min_angle', 0)}°")
                    col6.metric("Max Angle",        f"{data.get('max_angle', 0)}°")

                    col7, col8 = st.columns(2)
                    col7.metric("Avg YOLO Confidence", data.get('avg_confidence', 0))
                    col8.markdown(f"**Feedback:** {data.get('feedback_summary', '')}")

                except requests.exceptions.HTTPError as e:
                    st.error(f"Server error {r.status_code}: {r.text}")
                except requests.exceptions.Timeout:
                    st.warning("⏳ Request timed out. The video may be too long or the model is cold-starting. Try again.")
                except Exception as e:
                    st.error(f"Error connecting to backend: {e}")

elif choice == "AI Chat Buddy":
    st.subheader("💬 Virtual Gym Buddy")
    st.info("Ask me anything about workouts, diet, motivation, or recovery!")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    user_msg = st.text_input("You:", key="chat_input")

    if st.button("Send") and user_msg:
        try:
            r = requests.post(f"{BASE_URL}/api/buddy/chat", json={"message": user_msg}, timeout=10)
            r.raise_for_status()
            data = r.json()
            st.session_state.chat_history.append(("You", user_msg))
            st.session_state.chat_history.append(("Buddy 🤖", data.get("response", "")))
        except Exception as e:
            st.error(f"Error: {e}")

    for speaker, msg in st.session_state.chat_history:
        if speaker == "You":
            st.markdown(f"**🧑 {speaker}:** {msg}")
        else:
            st.markdown(f"**{speaker}:** {msg}")